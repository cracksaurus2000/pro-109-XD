# PROC109-V1-plantilla-proyecto
Teclado y mouse virtual.  
Python. pynput. PyAutoGUI.  
  
Tomando capturas de pantalla usando gestos.  
  
### Texto en inglés: project-C109-template
